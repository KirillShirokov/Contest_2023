# ID 89269781

def broken_search(arr, target) -> int:
    false_find = -1
    first = 0
    last = len(arr) - 1
    while first <= last:
        mid = (first + last) // 2
        if arr[mid] == target:
            return mid
        elif arr[first] <= arr[mid]:
            if arr[first] <= target < arr[mid]:
                last = mid - 1
            else:
                first =  mid + 1
        else:
            if arr[mid] < target <= arr[last]:
                first = mid + 1
            else:
                last = mid - 1
    return false_find


if __name__ == '__main__':
    len_array = int(input())
    find_num = int(input())
    num_array = [int(num) for num in input().split()]
    print(broken_search(num_array, find_num))

