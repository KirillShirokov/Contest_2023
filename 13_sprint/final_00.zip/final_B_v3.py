# ID 89333181

def compare(a, b):
    if a[1] != b[1]:
        return b[1] - a[1]
    elif a[2] != b[2]:
        return a[2] - b[2]
    else:
        if a[0] < b[0]:
            return False
        else:
            return True

def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if compare(arr[j], pivot) > 0:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]    
    arr[i+1], arr[high] = arr[high], arr[i+1]
    return i+1

def quicksort(arr, low, high):
    if low < high:
        pivot_idx = partition(arr, low, high)
        quicksort(arr, low, pivot_idx - 1)
        quicksort(arr, pivot_idx + 1, high)

def result(arr):
    for i in arr:
        print(i[0])


if __name__ == '__main__':
    number_of_players = int(input())
    list_players = [0] * number_of_players
    for i in range(number_of_players):
        name, points, fines = input().split()
        list_players[i] = [name, int(points), int(fines)]
    quicksort(list_players, 0, len(list_players) - 1)
    result(list_players[::-1])
