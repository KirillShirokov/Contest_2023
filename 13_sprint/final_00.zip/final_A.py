# ID 89269781

def step_up(mid):
    return mid + 1

def step_down(mid):
    return mid - 1

def broken_search(nums, target) -> int:
    false_find = -1
    first = 0
    last = len(nums) - 1   
    while first <= last:
        mid = (first + last) // 2
        if nums[mid] == target:
            return mid
        elif nums[first] <= nums[mid]:
            if nums[first] <= target < nums[mid]:
                last = step_down(mid)
            else:
                first = step_up(mid)
        else:
            if nums[mid] < target <= nums[last]:
                first = step_up(mid)
            else:
                last = step_down(mid)
    return false_find


def test():
    arr = [19, 21, 100, 101, 1, 4, 5, 7, 12]
    assert broken_search(arr, 5) == 6

