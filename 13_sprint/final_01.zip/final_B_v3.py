# ID 89350197

def compare(a, b):
    points_a, fines_a, name_a = a
    points_b, fines_b, name_b = b
    gr_num = (-points_a, fines_a, name_a)
    lt_num = (-points_b, fines_b, name_b)
    return gr_num < lt_num

def partition(arr, low, hight):
    pivot = arr[hight]
    i = low - 1
    for j in range(low, hight):
        if compare(arr[j], pivot) == True:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[hight] = arr[hight], arr[i + 1]
    return i + 1

def quicksort(arr, low, hight):
    if low < hight:
        pivot_idx = partition(arr, low, hight)
        quicksort(arr, low, pivot_idx - 1)
        quicksort(arr, pivot_idx + 1, hight)


if __name__ == '__main__':
    number_of_players = int(input())
    list_players = [0] * number_of_players
    for i in range(number_of_players):
        name, points, fines = input().split()
        list_players[i] = [int(points), int(fines), name,]
    quicksort(list_players, 0, len(list_players) - 1)
    for i in list_players:
        *_ , name = i
        print(name)
 